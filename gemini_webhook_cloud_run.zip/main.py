from flask import Flask, request, jsonify
import requests
import os

app = Flask(__name__)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

@app.route('/', methods=['POST'])
def handle_webhook():
    req_data = request.get_json()
    user_input = req_data.get("fulfillmentInfo", {}).get("tag", "Hello")

    # Call Gemini
    gemini_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent"
    headers = {"Authorization": f"Bearer {GEMINI_API_KEY}"}
    body = {
        "contents": [{"parts": [{"text": user_input}]}],
        "generationConfig": {"temperature": 0.7}
    }

    res = requests.post(gemini_url, headers=headers, json=body)
    output = res.json()["candidates"][0]["content"]["parts"][0]["text"]

    return jsonify({
        "fulfillment_response": {
            "messages": [{"text": {"text": [output]}}]
        }
    })

if __name__ == '__main__':
    app.run(debug=True)
